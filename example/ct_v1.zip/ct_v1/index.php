<?php

include 'init.php';

// Check if user is login or not. if not login will redirect to page set at parameter 3
// Note : change to login page instead of using welcome 
isLogin(true, 'isLogIn', 'app/views/welcome');
