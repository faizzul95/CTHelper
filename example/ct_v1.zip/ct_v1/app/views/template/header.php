<!-- important -->
<?php
include_once '../../init.php';
isLogin($loginRequired, 'isLogin', 'login');
?>

<!DOCTYPE html>

<!-- beautify ignore:start -->
<html lang="en"  >
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>

    <title><?= APP_NAME ?> | <?= $titlePage ?> </title>

    <base href="<?= BASE_URL ?>">
    <meta name="base_url" content="<?= BASE_URL ?>" />
    <meta name="description" content="" />
    
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="<?= asset('general/css/toastr.min.css'); ?>">
    <link rel="stylesheet" href="<?= asset('general/css/skeleton.css'); ?>">

    <script src="<?= asset('general/js/jquery.min.js'); ?>"></script>
    <script src="<?= asset('general/js/axios.min.js'); ?>"></script>
    <script src="<?= asset('general/js/jquery.min.js'); ?>"></script>
    <script src="<?= asset('general/js/helper.js'); ?>"></script>
    <script src="<?= asset('general/js/toastr.min.js'); ?>"></script>
    <script src="<?= asset('general/js/block-ui.js'); ?>"></script>
    <script src="<?= asset('general/js/validationJS.js'); ?>"></script>

    <!-- Sweetalert 2 -->
	  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    
    <!-- bootstrap datatable -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>

    <style>
        .swal2-customCss {
            z-index: 20000;
        }
    </style>

  </head>

  <body>