<?php

use Sys\framework\Database;

function db($connection = 'default')
{
    if ($connection == 'default') {
        $dbCon = ConfigDB();
        if (!Database::getInstance())
            return new Database($dbCon['driver'] ?? 'mysql', $dbCon['hostname'] ?? 'localhost', $dbCon['username'] ?? 'root', $dbCon['password'], $dbCon['database'], $dbCon['port'], $dbCon['charset']);
        else
            return Database::getInstance();
    } else {
        return connect($connection);
    }
}

// CONNECTION DATABASE SECTION

function ConfigDB($connection = 'default')
{
    global $config;

    if (hasData($config['db'], $connection)) {
        return $config['db'][$connection][ENVIRONMENT];
    }

    exit('Database connection ' . $connection . ' not found');
}

function connect($connection = 'default')
{
    global $config;

    if (hasData($config['db'], $connection)) {
        $db = Database::getInstance();
        $db->connect($connection);
        $db->connection($connection);
        return $db;
    } else {
        exit("No connection with <b>'$connection'</b> name");
    }
}
