<!-- Page JS -->
<script type="text/javascript">
    $(document).ready(function() {
        clock();
    });

    function clock() {
        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var d = new Date();
        var dayName = days[d.getDay()];

        let today = new Date().toLocaleDateString('en-GB', {
            month: '2-digit',
            day: '2-digit',
            year: 'numeric'
        });

        var display = new Date().toLocaleTimeString();
        $("#currentTime").html(dayName + ', ' + today + ' | ' + display);
        setTimeout(clock, 1000);
    }
</script>

<?= require_once '_modalGeneral.php' ?>

</body>

</html>